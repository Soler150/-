import Image from "next/image";

export default function MenuPage() {
  return (
    <section id="menu">
      <h2>Наше меню</h2>
      <div className="menu-items">
        {/* <!-- Бургер --> */}
        <div className="item">
          <Image width={100} height={1000} src="/burger.jpg" alt="Бургер" />
          <h3>Бургер</h3>
          <p>Вкусный и сочный бургер.</p>
          <span className="price">200₽</span>
        </div>
        {/* <!-- Картофель фри --> */}
        <div className="item">
          <Image
            width={100}
            height={1000}
            src="/fries.jpg"
            alt="Картофель фри"
          />
          <h3>Картофель фри</h3>
          <p>Хрустящий картофель.</p>
          <span className="price">100₽</span>
        </div>
        {/* <!-- Пицца --> */}
        <div className="item">
          <Image width={100} height={1000} src="/pizza.jpg" alt="Пицца" />
          <h3>Пицца</h3>
          <p>Пицца с сыром, ветчиной и грибами.</p>
          <span className="price">350₽</span>
        </div>
        {/* <!-- Салат Цезарь --> */}
        <div className="item">
          <Image
            width={100}
            height={1000}
            src="/caesar.jpg"
            alt="Салат Цезарь"
          />
          <h3>Салат Цезарь</h3>
          <p>Свежий салат с курицей и соусом Цезарь.</p>
          <span className="price">250₽</span>
        </div>
        {/* <!-- Шаурма --> */}
        <div className="item">
          <Image width={100} height={1000} src="/shawarma.jpg" alt="Шаурма" />
          <h3>Шаурма</h3>
          <p>Большая шаурма с курицей, овощами и соусом.</p>
          <span className="price">300₽</span>
        </div>
        {/* <!-- Суши --> */}
        <div className="item">
          <Image width={100} height={1000} src="/sushi.jpg" alt="Суши" />
          <h3>Суши</h3>
          <p>Набор из 6 роллов с лососем.</p>
          <span className="price">400₽</span>
        </div>
        {/* <!-- Кофе --> */}
        <div className="item">
          <Image width={100} height={1000} src="/coffee.jpg" alt="Кофе" />
          <h3>Кофе</h3>
          <p>Крепкий эспрессо или капучино на выбор.</p>
          <span className="price">150₽</span>
        </div>
        {/* <!-- Морс --> */}
        <div className="item">
          <Image width={100} height={1000} src="/mors.jpg" alt="Морс" />
          <h3>Морс</h3>
          <p>Свежий ягодный морс.</p>
          <span className="price">100₽</span>
        </div>
      </div>
    </section>
  );
}

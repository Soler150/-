export default function contactPage() {
  return (
    <section id="contact">
      <h2>Контакты</h2>
      <p>Адрес: Улица Пушкина, дом 10</p>
      <p>Телефон: +7 (999) 123-45-67</p>
      <p>Email: info@minutka.ru</p>
    </section>
  );
}

import Image from "next/image";

export default function Home() {
  return (
    <>
      {/* Слайдер  */}
      <section id="slider">
        <div className="slider-wrapper">
          <div className="slide active">
            <img src="slider1.jpg" alt="Вкусный бургер" />
            <div className="caption">Попробуйте наш фирменный бургер!</div>
          </div>
          <div className="slide">
            <img src="slider2.jpg" alt="Картофель фри" />
            <div className="caption">Хрустящий картофель фри со скидкой!</div>
          </div>
          <div className="slide">
            <img src="slider3.jpg" alt="Свежий салат" />
            <div className="caption">Здоровый и вкусный салат для вас.</div>
          </div>
        </div>
        <div className="slider-controls">
          <button id="prev">❮</button>
          <button id="next">❯</button>
        </div>
      </section>

      {/* Блок акций */}
      <section id="promotions">
        <h2>Наши акции</h2>
        <div className="promotion">
          <h3>Скидка 20% на всё меню в будние дни!</h3>
          <p>
            Приходите к нам в будние дни с 12:00 до 15:00 и получите скидку на
            все блюда.
          </p>
        </div>
        <div className="promotion">
          <h3>Купите один бургер — второй в подарок!</h3>
          <p>
            При заказе любого бургера, получите второй бесплатно в течение дня.
          </p>
        </div>
      </section>

      {/*  Популярные блюда */}
      <section id="popular-dishes">
        <h2>Популярные блюда</h2>
        <div className="menu-items">
          <div className="item">
            <Image src="/burger.jpg" width={1000} height={1000} alt="Бургер" />
            <h3>Фирменный бургер</h3>
            <p>Сочный и сытный бургер с идеальными пропорциями.</p>
            <span className="price">200₽</span>
          </div>
          <div className="item">
            <Image
              src="/fries.jpg"
              width={1000}
              height={1000}
              alt="Картофель фри"
            />
            <h3>Картофель фри</h3>
            <p>
              Золотистый и хрустящий картофель, который так и хочется съесть.
            </p>
            <span className="price">100₽</span>
          </div>
          <div className="item">
            <Image
              src="/salad.jpg"
              width={1000}
              height={1000}
              alt="Свежий салат"
            />
            <h3>Свежий салат</h3>
            <p>Здоровое сочетание свежих овощей с фирменным соусом.</p>
            <span className="price">150₽</span>
          </div>
        </div>
      </section>
    </>
  );
}

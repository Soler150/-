import Link from "next/link";

export default function LoginPage() {
  return (
    <div className="container">
      <div className="formWrapper">
        <h2>Войти</h2>
        <form className="form">
          <div className="inputGroup">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" required />
          </div>
          <div className="inputGroup">
            <label htmlFor="password">Пароль</label>
            <input type="password" id="password" name="password" required />
          </div>
          <button type="submit" className="submitButton">
            Войти
          </button>
        </form>
        <p>
          Нет аккаунта?{" "}
          <Link href="/register" className="link">
            Зарегистрируйтесь
          </Link>
        </p>
      </div>
    </div>
  );
}

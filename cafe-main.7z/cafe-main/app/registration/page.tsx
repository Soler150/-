import Link from "next/link";

export default function RegistrationPage() {
  return (
    <div className="container">
      <div className="formWrapper">
        <h2>Регистрация</h2>
        <form className="form">
          <div className="inputGroup">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" required />
          </div>
          <div className="inputGroup">
            <label htmlFor="password">Пароль</label>
            <input type="password" id="password" name="password" required />
          </div>
          <button type="submit" className="submitButton">
            Зарегистрироваться
          </button>
        </form>
        <p>
          Уже есть аккаунт?{" "}
          <Link href="/login" className="link">
            Войти
          </Link>
        </p>
      </div>
    </div>
  );
}

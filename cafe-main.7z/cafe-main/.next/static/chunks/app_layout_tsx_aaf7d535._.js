(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__98144f0b._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_de587c48._.js",
    "static/chunks/node_modules_next_dist_9a2d5fdb._.js"
  ],
  "source": "dynamic"
});

(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_tsx_2a8ecc8e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_tsx_2a8ecc8e._.js",
  "chunks": [
    "static/chunks/app_login_Auth_module_76f6e786.css"
  ],
  "source": "dynamic"
});

export function Footer() {
  return (
    <footer>
      <p>&copy; 2025 Минутка. Все права защищены.</p>
    </footer>
  );
}

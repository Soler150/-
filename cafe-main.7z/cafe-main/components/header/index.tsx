import Link from "next/link";

export function Header() {
  return (
    <header>
      <div className="logo">
        <h1>Минутка</h1>
      </div>
      <nav>
        <ul>
          <li>
            <Link href="/">Главная</Link>
          </li>
          <li>
            <Link href="/menu">Меню</Link>
          </li>
          <li>
            <Link href="/about">О нас</Link>
          </li>
          <li>
            <Link href="/contact">Контакты</Link>
          </li>
        </ul>
      </nav>

      <Link href="/login">
        <button>Войти</button>
      </Link>
      <Link href="/registration">
        <button>Регистрация</button>
      </Link>
    </header>
  );
}
